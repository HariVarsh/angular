const nodemailer = require('nodemailer')

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'documentterm@gmail.com',
        pass: 'Password@123'
    }
});

module.exports.Send = function Send(to, subject, text) {
    mailOptions = transporter.sendMail({
        from: '"Document Term"<documentterm@gmail.com>',
        to: to,
        subject: subject,
        text: text
    }, (err, info) => {
        if (err) 
            console.log(err);
         else 
            console.log(info);
    });
}

