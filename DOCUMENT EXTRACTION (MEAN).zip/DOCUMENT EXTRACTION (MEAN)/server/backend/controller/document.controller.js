const documentService=require('../service/document.service');

function getClientDocuments(req,res)
{    
documentService.getClientDocuments(req).then(documents => {
  res.status(documents.code).send(documents.body);
})
.catch(error=>{
  res.status(error.code).json({
  message:error.message
  })
})
} 

function removeDocumentType(req,res)
{
documentService.removeDocumentType(req).then(doc=>{
    res.status(doc.code).json({
      message:doc.message,
      documents:doc.body
    })
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}
function addDocumentType(req,res)
{
documentService.addDocumentType(req).then(doc=>{
    res.status(doc.code).send(doc.body)
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}

module.exports={
    getClientDocuments,
    removeDocumentType,
    addDocumentType
}