const msalService = require('../service/msal.service');

async function UserLogin(req,res)
{
  let token = await req.headers['authorization'];
  //console.log(token);
  if(token.startsWith('Bearer '))
  token= token.slice(7,token.length);
  console.log('token sliced');
  msalService.verifyToken(token).then(
    output=>{
      console.log("controller");
      console.log(output)
      res.status(201).json(output);
    }
  )
  .catch(output=>{
    res.status(404).json({
      message:'Unsuccesful login attempt'
    });
  })

}
module.exports={
  UserLogin
}
