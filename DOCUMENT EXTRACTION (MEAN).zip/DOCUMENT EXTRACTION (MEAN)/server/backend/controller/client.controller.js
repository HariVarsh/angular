const clientService = require('../service/client.service');

function GetClients(req,res){
    clientService.GetClients().then(documents=>{
        res.status(200).send(documents.body);
    })
    .catch(err=>{
        res.status(err.code).json({
            message:err.message
        })
    })
}
 
function GetClient(req,res){
    clientService.GetClient(req).then(documents=>{
        // res.status(200).json({
        //     message:documents.message,
        //     clients:documents.body
        // });
        res.status(200).send(documents.body);
    })
    .catch(err=>{
        res.status(err.code).json({
            message:err.message
        })
    })
}

function AddClient(req,res){
    clientService.AddClient(req).then(documents=>{
        // res.status(200).json({
        //     message:documents.message,
        //     clients:documents.body
        // });
        res.status(200).send(documents.body);
    })
    .catch(err=>{
        res.status(err.code).json({
            message:err.message
        })
    })
}

function UpdateClient(req,res){
    clientService.UpdateClient(req).then(documents=>{
        // res.status(200).json({
        //     message:documents.message,
        //     clients:documents.body
        // });
        res.status(200).send(documents.body);
    })
    .catch(err=>{
        res.status(err.code).json({
            message:err.message
        })
    })
}

function DeleteClient(req,res){
    clientService.DeleteClient(req).then(documents=>{
        // res.status(200).send({
        //     message:documents.message,
        //     clients:documents.body
        // });
        res.status(200).send(documents.body);
    })
    .catch(err=>{
        res.status(err.code).json({
            message:err.message
        })
    })
}

module.exports={
    GetClients,
    GetClient,
    DeleteClient,
    AddClient,
    UpdateClient
}