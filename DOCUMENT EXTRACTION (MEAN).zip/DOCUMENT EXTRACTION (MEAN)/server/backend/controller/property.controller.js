const propertyService=require('../service/property.service');
const Property=require("../models/Property");
const Subtype=require('../models/subtype');

function deleteProperty(req,res)
{
propertyService.deleteProperty(req).then(doc=>{
    res.status(doc.code).json({
        body:doc.body,
        message: doc.message
      });
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}

function addProperty(req,res)
{
    const newProperty= new Property(
        {
            propertyName:req.body.property,
            subtype:[]
        }
    )
propertyService.addProperty(req).then(doc=>{
    res.status(doc.code).json({
        body:newProperty,
        message: doc.message
      });
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}

function addSubtype(req,res)
{
    const subtype=new Subtype(
        {
            name:req.body.subtype,
            datatype:req.body.option
        }
    )
propertyService.addSubtype(req).then(doc=>{
    res.status(doc.code).json({
        body:subtype,
        message: doc.message
      });
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}

function removeSubtype(req,res)
{
propertyService.removeSubtype(req).then(doc=>{
    res.status(doc.code).json({
        body:doc.body,
        message: doc.message
      });
  })
  .catch(error=>{
   res.status(error.code).json({
    message: error.message
  });
 });
}
module.exports={
    deleteProperty,
    addProperty,
    addSubtype,
    removeSubtype
}