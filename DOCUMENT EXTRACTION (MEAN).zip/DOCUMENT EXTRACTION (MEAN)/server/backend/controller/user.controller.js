const userService=require('../service/user.service')
function GetAllusers(req,res){
  res.status(201).json({
    message:'Got Access'
  });
}
function getUserByEmail(req,res){
  userService.getUserByEmail(req.params.userEmail).then(client=>{
    res.status(200).json({
      message:"Client Fetched",
      clientData:client
    })
  }).catch(err=>{
    res.status(400).json({
      message:"Error while fetching data",
      error:err
    })
  })
}

function getUsers(req,res)
{
userService.getUsers().then(documents => {
  res.status(200).json({
    message:documents.message,
    users: documents.body
  }); 
})
.catch(error=>{
  res.status(error.code).json({
  message:error.message
  })
})
}

function updateUser(req,res)
{
 // console.log(req.body);  
userService.updateUser(req).then(data=>{
  res.status(data.code).json({
    message:data.message,
    employee:req.body
  }); 
})
.catch(error=>{
  res.status(error.code).json({
  message:error.message
  })
})
}
 module.exports={
   GetAllusers,
   getUsers,
   updateUser,
   getUserByEmail
 }
