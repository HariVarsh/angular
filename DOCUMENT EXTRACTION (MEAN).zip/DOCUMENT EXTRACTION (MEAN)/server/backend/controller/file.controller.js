const fileService=require('../service/file.service');

function saveFile(req,res){
    
    
    fileService.saveFile(req).then(success=>{
        console.log(success);
        
        res.status(200).json({
            message:"Saved Successfully"
        })
    }).catch(error=>{
        res.status(400).json({
            message:"Error while saving the file"
        })
    })
}
function getTotalPosts(req,res){
    fileService.getTotalPosts(req.params.id).then(document=>{
        res.status(200).json({
            message:document.message,
            posts:document.body
        })
    }).catch(error=>{
        res.status(400).json({
            message:error.message
        })
    })
}
function getUserHistory(req,res){
    fileService.getUserHistory(req.params.id,req.query.pageSize,req.query.page).then(documents=>{
        res.status(200).json({
            message:documents.message,
            users:documents.body
        });
    })
    .catch(error=>{
        console.log(error);
        
        res.status(400).json({
            message:error.message
        })
    })
}
module.exports={
    getUserHistory,
    getTotalPosts,
    saveFile
}