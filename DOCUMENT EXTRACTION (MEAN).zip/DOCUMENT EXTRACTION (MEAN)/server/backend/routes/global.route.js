//adding required dependencies
const express = require('express');
const router = express.Router();
const userRoutes = require("./user");
const clientRoutes = require("./client");
const clientRoutes2 = require('./client.routes');
const documentRoutes = require("./document");
const uploadRoutes = require("./file");
const route = require('./route.js');
 
//middleware
const auth =require('../middleware/auth');
//get user controller
const user = require('../controller/user.controller');
//Msal controller
const msal = require('../controller/msallogin.controller');
//msal login route
router.post('/post',msal.UserLogin);
//Msal get route
router.get('/users/get',auth.adminAuthorization, user.GetAllusers);
router.use("/user", userRoutes);
router.use("/clients2",clientRoutes2);
router.use("/clients", clientRoutes);
router.use("/document", documentRoutes);
router.use("/upload",uploadRoutes);
router.use("/", route);

module.exports = router;
