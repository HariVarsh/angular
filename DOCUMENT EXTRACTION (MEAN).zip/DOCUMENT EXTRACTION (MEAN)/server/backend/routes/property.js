const express = require("express");
const propertyController=require('../controller/property.controller');
const prouter = express.Router();

prouter.post("/delete/:id/:tname",propertyController.deleteProperty);
prouter.post("/addProperty/:id/:tid",propertyController.addProperty);
prouter.post("/addSubType/:id/:pname",propertyController.addSubtype)
prouter.post("/removeSubType/:id/:pname",propertyController.removeSubtype)
module.exports=prouter;