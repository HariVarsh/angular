
const express = require("express");
const documentController=require('../controller/document.controller');
const router = express.Router();
const propertyRoutes = require("./property");
  
  router.get("/:id",documentController.getClientDocuments);

  router.post("/removeType/:did",documentController.removeDocumentType);

  router.post("/addType/:did",documentController.addDocumentType);
 
  router.use("/property",propertyRoutes);
  module.exports = router; 