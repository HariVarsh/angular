
const express = require("express");
const User=require("../models/msal.model");
const router = express.Router();
const userController=require('../controller/user.controller')

router.get("/retrieve",userController.getUsers);
router.get("/:userEmail",userController.getUserByEmail);
router.post("/update",userController.updateUser)

module.exports = router;
  