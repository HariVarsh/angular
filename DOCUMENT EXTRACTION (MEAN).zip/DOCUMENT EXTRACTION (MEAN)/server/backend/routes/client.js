const express = require("express");
const Client = require("../models/client");
const User = require('../models/user');
const router = express.Router();
const mail = require('../messageProto');
const ObjectId  = require("mongoose").Types.ObjectId;

router.get('/', (req, res) => {
    Client.find((err, doc) => {
        if (!err) 
            res.send(doc);
         else 
            console.log('Can\'t retrive clients, Error : ' + JSON.stringify(err, undefined, 2));
    });
});  

router.post('/', (req, res, err) => {
    var client = new Client({name: req.body.name, email: req.body.email});

    client.save((err, doc) => {
        if (!err) {
            res.send(doc);
            mail.Send(doc.email, 'Client Registered', doc.name + ' Congrats,\nYou have been successfully registered for docExtract');
        } else 
            {
                if(err['message']=="Client validation failed: email: Path `email` is required.")
                    res.status(400).send("Email is required");
                else if(err['message']=="Client validation failed: name: Path `name` is required.")
                    res.status(400).send("Name is required");
                else if(err['message']=="Email Id already exists")
                    res.status(400).send("The provided email id exists, enter a different one");
                else if(err['message']=="Client validation failed: email: Validator failed for path `email` with value `"+req.body.email+"`")
                    res.status(400 ).send("Email ID is invalid");
            }
    })
});

router.get('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id)) 
        return res.status(400).send('No Record with the ID : ' + req.params.id);
    
    Client.findById(req.params.id, (err, doc) => {
        if (!err) 
            res.send(doc);
         else 
            console.log('can\'t retrive client, error : ' + JSON.stringify(err, undefined, 2));
    });
});

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id)) 
        return res.status(400).send('No Record with the ID : ' + req.params.id);
    
    Client.findByIdAndRemove(req.params.id, (err, doc) => {
        console.log(req.params.id);
        if (!err) {
            User.update({clientId:req.params.id},{$set:{clientId:""}},{multi:true},
            (err,res)=>{
                if(err)
                    console.log('Error found');
                else
                    console.log(res);
            });
            res.send(doc);
            mail.Send(doc.email, 'Client Removed', doc.name + ' Thank you for using docExtract\nHope to see you soon');
        } else 
            console.log('can\'t delete client, error : ' + JSON.stringify(err, undefined, 2));
        
    });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id)) 
        return res.status(400).send('No Record with the ID : ' + req.params.id);
    
    var client = {
        name: req.body.name,
        email: req.body.email
    };
    Client.findByIdAndUpdate(req.params.id, {
        $set: client
    }, {
        new: true
    }, (err, doc) => {
        if (!err) 
            res.send(doc);
         else 
         {
             if(err['message']=="Client validation failed: email: Path `email` is required.")
                 res.status(400).send("Email is required");
             else if(err['message']=="Client validation failed: name: Path `name` is required.")
                 res.status(400).send("Name is required");
             else if(err['message']=="Email Id already exists")
                 res.status(400).send("The provided email id exists, enter a different one");
             else if(err['message']=="Client validation failed: email: Validator failed for path `email` with value `"+req.body.email+"`")
                 res.send("Email ID is invalid");
             else
                res.send(err['message']);
         }
    });
});

module.exports = router;
