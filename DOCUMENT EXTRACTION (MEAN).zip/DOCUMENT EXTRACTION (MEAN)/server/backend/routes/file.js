const express = require("express");
const multer = require("multer");
const router = express.Router();
const fs = require("fs");
const folderName = '/Windows/Temp/Assets/';
const fileController=require('../controller/file.controller');
const MIME_TYPE_MAP = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "application/pdf": "pdf"
};

router.get("/:id",fileController.getUserHistory);
router.get("/total/:id",fileController.getTotalPosts);

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        try {
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
            }
        } catch (error) {
            console.log(error);

        }
        try {
            const isValid = MIME_TYPE_MAP[file.mimetype];
            if (!isValid) {
                throw new InvalidMimeType("Invalid Mime Type");
            }
            cb(null, folderName);
        } catch (error) {
            console.log(error.message);


        }
    },
    filename: (req, file, cb) => {
        const ext = file.originalname.toLowerCase().split(".");
        const name = ext[0] + Date.now() + "." + ext[1]
            .split(" ")
            .join("-");
        cb(null, name);
    }
});

router.post(
    "",
    multer({ storage: storage }).single("file"),fileController.saveFile
   
);

module.exports = router;
