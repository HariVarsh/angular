const express = require('express');
const router = express.Router();
var path = require('path')
var mongoose = require('mongoose')

const Document = require('../models/document')
const DocumentType = require('../models/documentType')
const Property = require('../models/Property')
const Subtype = require('../models/subtype')
const Client = require('../models/client')
 
//post document
router.post('/addDocument', (req, res, next) => {
    let flag = 0
    let newDocument = new Document({
        documentName: req.body.documentName,
        clientId: req.body.clientId,

    })
    Document.find({ clientId: req.body.clientId }, (err, data) => {
        if (err) {
            console.log(err);
        }
        else {
            for (let i = 0; i < data.length; i++) {
                if (data[i].documentName === req.body.documentName) {
                    flag = 1
                    break;
                }
                else { flag = 0 }
            }
            if (flag == 0) {
                newDocument.save((err, success) => {
                    if (err) {
                        console.log(err);

                        res.json("could not add new document " + err)
                    }
                    else {
                        res.json("added new Document ");
                    }
                })
            }
            else {

                res.json("This document already exists")
            }
        }
    })

})


//post documentType
router.post("/addDocumentType/:docId", (req, res, next) => {
    let newDocumentType = new DocumentType(
        {
            documentTypeName: req.body.documentTypeName,
            id: req.body.id,
            properties:[]
        })

    Document.findOneAndUpdate({ _id: req.params.docId },

        { $addToSet: { documentTypes: newDocumentType } },

        (err, data) => { if (err) { res.send(err) } else { res.send(data) } })

})




//post new property
router.post('/addProperty/:docId/:docTypeName', (req, res) => {
    let newProp = new Property({
        propertyName: req.body.propertyName,
        subtype: []
    })
    console.log(req.body);

    Document.updateOne({ _id: req.params.docId },
        { $addToSet: { "documentTypes.$[elem].properties": newProp } },
        { arrayFilters: [{ "elem.documentTypeName": req.params.docTypeName }] },
        (err,data) => {if(err){res.send("could not add new property"+err)}else{res.send("new property added successfully")} })
})



//post new subType
router.post('/addSubType/:docId/:docTypeName/:propName', (req, res) => {

    let newSubType = new Subtype({
        name: req.body.name,
        datatype: req.body.datatype
    })
    Document.updateOne({ _id: req.params.docId },
        { $addToSet: { "documentTypes.$[elem].properties.$[elem1].subtype": newSubType } },
        { arrayFilters: [{ "elem.documentTypeName": req.params.docTypeName }, { "elem1.propertyName": req.params.propName }], multi: true },
        (err, succ) => {
            if (err) {
                res.send("updation failure")
            }
            else
                res.json("new subType added successfully")
        })
})




//get documents
router.get('/getDocuments/:clientId', (req, res, next) => {
    Document.find({ clientId: req.params.clientId }, (err, doc) => {
        if (err) {
            res.send("no documents")
        }
        else {
            res.send(doc);
        }
    })
})

// //get Document Types
// router.get("/getDocumentTypes/:documentName", (req, res) => {
//     Document.find({ documentName: req.params.documentName }).then(doc => {
//         res.send(doc)
//     })
// })

//get client
router.get("/getClient", (req, res, next) => {
    Client.find((err, doc) => {
        if (err) {
            res.send("no clients")
        }
        else {
            res.send(doc);
        }
    });

})

//add new client
router.post('/post', (req, res) => {
    let newClient = new Client({
        name: req.body.name
    })
    newClient.save((err, success) => {
        if (err) {
            res.json("could not add new client " + err)
        }
        else {
            res.json("added new client ");
        }
    })
})

module.exports = router;
