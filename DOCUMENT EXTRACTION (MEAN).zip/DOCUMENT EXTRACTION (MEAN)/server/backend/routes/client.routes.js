const clientController = require('../controller/client.controller');
const express = require('express');

const router = express.Router();

router.get('/',clientController.GetClients);

router.get('/:id',clientController.GetClient);

router.post('/',clientController.AddClient);

router.put('/:id',clientController.UpdateClient);

router.delete('/:id',clientController.DeleteClient);

module.exports = router;