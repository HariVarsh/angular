let mongoose=require("mongoose");
let file=require("../models/file");
let chai=require("chai");
let chaiHttp=require('chai-http');
let server=require('../../server');
let should=chai.should();
chai.use(chaiHttp);

describe('file',()=>{
    beforeEach((done)=>{
        file.remove({},(err)=>{
            done();
        })
    })
})