const Document=require("../models/document");
const Property=require("../models/Property");
const Subtype=require('../models/subtype');

function deleteProperty(req)
{
    return   Document.update({_id:req.params.id},{$pull:
        {"documentTypes.$[elem].properties":{propertyName:req.body.propertyName}}},
        {arrayFilters: [{ "elem.documentTypeName": req.params.tname}]},()=>{})
}

function addProperty(req)
{
    const newProperty= new Property(
        {
            propertyName:req.body.property,
            subtype:[]
        }
    )

   return Document.update({_id:req.params.id},{$addToSet:
        {"documentTypes.$[elem].properties":newProperty}},{ arrayFilters: [{ "elem.documentTypeName": req.params.tid}] },
        (err,data)=>{
            if(err)
            {flag=1}
        })
}

function addSubtype(req)
{
    const subtype=new Subtype(
        {
            name:req.body.subtype,
            datatype:req.body.option
        }
    )
       
   return Document.update({_id:req.params.id},{$addToSet:
        {"documentTypes.$[].properties.$[elem].subtype":subtype}},
        { arrayFilters: [{ "elem.propertyName": req.params.pname}] },()=>{})
}

function removeSubtype(req)
{
 
   return Document.update({_id:req.params.id},{$pull:
        {"documentTypes.$[].properties.$[elem].subtype":{name:req.body.name}}},
        { arrayFilters: [{ "elem.propertyName": req.params.pname}] },()=>{})
}
module.exports={
    deleteProperty,
    addProperty,
    addSubtype,
    removeSubtype
}