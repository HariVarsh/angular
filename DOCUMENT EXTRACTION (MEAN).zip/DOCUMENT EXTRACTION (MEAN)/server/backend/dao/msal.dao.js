const msalUser = require("../models/msal.model");

function addUserToDb(user){
  let newUser= new msalUser(user);
  console.log('new user:'+newUser);
  return newUser.save();
}
function checkUserInDb(email){
  return msalUser.findOne({email});
}
function saveToken(userData)
{
  msalUser.findOneAndUpdate({email:userData.email},{token:userData.token}).then(data=>
    {

    }).catch(err=>{
      console.log(err)
    })
}

function GetRole(UserEmail){
  console.log("-------------");

  console.log(UserEmail);
  console.log('-----------------')
  console.log(msalUser.findOne({email:UserEmail}));
  return msalUser.findOne({email:UserEmail});

}
function removeToken(id)
{
  return msalUser.findByIdAndUpdate({_id:id},{token:null})
}

function sendData(role){
  console.log('Daolayer',role);

  return role;
}
function checkUserPrivilige(userEmail){
  return msalUser.findOne({email:userEmail});
}
module.exports={
  addUserToDb,
  checkUserInDb,
  saveToken,
  removeToken,
  checkUserPrivilige,
  GetRole
}
