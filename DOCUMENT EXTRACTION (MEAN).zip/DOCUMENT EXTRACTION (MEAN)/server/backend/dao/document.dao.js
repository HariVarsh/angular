const Document = require("../models/document");
const DocumentType=require("../models/documentType")

function getClientDocuments(req)
{
return Document.find({
  
    clientId: req.params.id
  })
}
function removeDocumentType(req)
{
    
 return Document.update({_id:req.params.did},
    {$pull:{documentTypes:{documentTypeName:req.body.documentTypeName,properties:req.body.properties}}}
    ,()=>{})
}

function addDocumentType(req)
{
    const newEntity= new DocumentType(
        {
          documentTypeName: req.body.documentType,
          properties: []
      })
    //  console.log(newEntity);
      
  return Document.findOneAndUpdate({_id:req.params.did},{$addToSet:{documentTypes:newEntity}},()=>{})
}
module.exports={
    getClientDocuments,
    removeDocumentType,
    addDocumentType
}