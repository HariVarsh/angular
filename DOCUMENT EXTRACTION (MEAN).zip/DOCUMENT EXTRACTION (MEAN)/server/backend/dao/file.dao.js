const File=require('../models/file');
function getTotalPosts(userId){
    return File.count({userId:userId});
}
function getUserHistory(userId,pageSize,currentPage){
    const postQuery = File.find({ userId: userId });
    if (pageSize && currentPage) {
     return postQuery.skip(parseInt(pageSize) * (parseInt(currentPage) - 1))
            .limit(parseInt(pageSize));
    }
}
function saveFile(req){
    let date_ob = new Date();
    file = new File({
        
        userId: req.body.userId,
        clientId: req.body.clientId,
        doc: req.body.documentName,
        ent: req.body.entityName,
        filePath: "https://documenttermextractionte.blob.core.windows.net/uploads2/" + req.file.filename,
        timeStamp: ("0" + date_ob.getDate()).slice(-2) + "-" + ("0" + (date_ob.getMonth() + 1)).slice(-2) + "-" + date_ob.getFullYear() + " " + date_ob.getHours() + ":" + date_ob.getMinutes() + ":" + date_ob.getSeconds()
    });
    console.log(file);
    
    return file.save();
}
module.exports={
    getUserHistory,
    getTotalPosts,
    saveFile
}