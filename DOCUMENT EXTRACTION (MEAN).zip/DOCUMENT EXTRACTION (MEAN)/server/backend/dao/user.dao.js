const User=require("../models/msal.model");

function getUsers()
{
    return User.find();
}
function getUserByEmail(userEmail){
    return User.find({email:userEmail});
}

function updateUser(req)
{
    //console.log("dao says   "+req.body);
    
   return User.update(
           { _id: req.body._id },
           { $set:
              {
                clientId:req.body.clientId
              }
           },()=>{}
    
        )
}
module.exports={
    getUsers,
    updateUser,
    getUserByEmail
}