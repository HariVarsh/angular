const Client = require('../models/client');
const User = require('../models/user');
const NewUser = require('../models/msal.model')

function GetClients(){
    return Client.find();
}
 
function GetClient(req){
    return Client.findById(req.params.id);
}

function AddClient(req){
    var client = new Client({name:req.body.name,email:req.body.email});
    return client.save();
}

function UpdateClient(req){
    var client = {
        name: req.body.name,
        email: req.body.email
    };
    return Client.findByIdAndUpdate(req.params.id,{$set:client},{new:true});
}

function DeleteClient(req){
    return Client.findByIdAndRemove(req.params.id); 
}

function UpdateUsers(req){
    NewUser.update({clientId:req.params.id},{$set:{clientId:""}},{multi:true},(err,raw)=>{
        if(!err)
            console.log(raw);
        else
            console.log(err);
    });
    User.update({clientId:req.params.id},{$set:{clientId:""}},{multi:true});
}

module.exports={
    GetClients,
    GetClient,
    AddClient,
    UpdateClient,
    DeleteClient,
    UpdateUsers
}