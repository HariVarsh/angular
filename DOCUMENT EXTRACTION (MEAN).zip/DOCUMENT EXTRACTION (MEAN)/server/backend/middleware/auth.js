const jwt = require('jsonwebtoken');
const dao = require('../dao/msal.dao');
const epoch = require('unix-timestamp');
const constantConfigs=require('./../config/msal.config');

function adminAuthorization(req,res){
  var token = req.headers['authorization'];
  if(token.startsWith('Bearer '))
  token= token.slice(7,token.length);
  console.log('token sliced');
  if(token){
    var accessTokenData= jwt.decode(token);
    var expiresAt= epoch.toDate(accessTokenData.nbf);
    var currentDate= new Date();
    var timeDiff=expiresAt-currentDate;
    userEmailToken= accessTokenData.unique_name;

    if(timeDiff >=0 && accessTokenData.iss === constantConfigs.issuer && accessTokenData.aud===constantConfigs.audience){
      console.log('token verified');
      if(dao.checkUserInDb(userEmailToken)){
        console.log('email present');
        dao.checkUserPrivilige(userEmailToken).then(data=>{
          console.log(data.role);
          if(data.role==='Admin'){
            return res.status(200).json({
              status:true,
              message:'access granted'
            });
          }
          else{
            return res.status(401).json({
              status:false,
              message:'user doesnt have admin priviliges'
            });
          }
        });
      }
    }
    else{
      return res.status(401).json({
        status:false,
        message:'token verification failed'
      })
    }
  }else{
    return res.status(403).json({
      status:false,
      message:'token not present'
    });
  }
}

function userAuthorization(req,res){
  var token = req.headers['authorization'];
  if(token.startsWith('Bearer '))
  token= token.slice(7,token.length);
  console.log('token sliced');
  if(token){
    var accessTokenData= jwt.decode(token);
    var expiresAt= epoch.toDate(accessTokenData.nbf);
    var currentDate= new Date();
    var timeDiff=expiresAt-currentDate;
    userEmailToken= accessTokenData.unique_name;

    if(timeDiff >=0 && accessTokenData.iss === constantConfigs.issuer && accessTokenData.aud===constantConfigs.audience){
      console.log('token verified');
      if(dao.checkUserInDb(userEmailToken)){
        console.log('email present');
        dao.checkUserPrivilige(userEmailToken).then(data=>{
          console.log(data.role);
          if(data.role==='User'){
            return res.status(200).json({
              status:true,
              message:'access granted for user priviliges'
            });
          }
          else{
            return res.status(401).json({
              status:false,
              message:'user doesnt have user priviliges'
            });
          }
        });
      }
    }
    else{
      return res.status(401).json({
        status:false,
        message:'token verification failed'
      })
    }
  }else{
    return res.status(403).json({
      status:false,
      message:'token not present'
    });
  }
}
module.exports={
  adminAuthorization,userAuthorization
}
