const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const app = express();
const globalroute = require('./routes/global.route');

mongoose.connect('mongodb://13.71.82.109:27017/DocumentConfig', { useNewUrlParser: true })
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use((req, response, next) => {
  response.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
  response.setHeader("Access-Control-Allow-Credentials", "true");
  response.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
  response.setHeader("Access-Control-Allow-Headers",
  "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,Authorization,accessTOken");
  if(req.method==='OPTIONS'){
    response.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
  response.setHeader("Access-Control-Allow-Headers",
   "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,Authorization,accessTOken");
    return response.status(200).json({});
  }
  next();
});

app.use('/api',globalroute);
// app.use("/api/user", userRoutes);
// app.use("/api/clients", clientRoutes);
// app.use("/api/document", documentRoutes);
// app.use("/api/upload", uploadRoutes);
// app.use("/api/addDocument", route);
module.exports = app;
