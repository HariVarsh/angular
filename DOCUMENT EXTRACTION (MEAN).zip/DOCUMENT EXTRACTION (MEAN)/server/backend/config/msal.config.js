const audience ='00000003-0000-0000-c000-000000000000'
const issuer='https://sts.windows.net/d798fc0a-90d4-47e5-a072-e6b2dbfab70a/';
module.exports={
  audience:audience,
  issuer:issuer
}
