const mongoose = require('mongoose');
var documentType = require('./documentType');


const documentSchema = mongoose.Schema({
 documentName: { type: String, required: true },
 clientId: {type:String,required:true},
 documentTypes:{type:[mongoose.Schema.Types.Mixed],ref:documentType,required:true}
});

//documentSchema.plugin(uniqueValidator);
module.exports = mongoose.model('Document', documentSchema);
