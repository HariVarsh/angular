const mongoose = require('mongoose');

const clientSchema = mongoose.Schema({
  name: { type: String, required: true },
  email: {type:String,required:true,unique:true,validate:/^[a-zA-Z]{1}[a-zA-Z0-9.\-_]*@[a-zA-Z]{1}[a-zA-Z.-]*[a-zA-Z]{1}[.][a-zA-Z]{2,}$/}
});

clientSchema.post('save', function(error, doc, next) {
  if (error.name === 'MongoError' && error.code === 11000) {
    next(new Error('Email Id already exists'));
  } else {
    next(error);
  }
});

module.exports = mongoose.model('Client', clientSchema);
