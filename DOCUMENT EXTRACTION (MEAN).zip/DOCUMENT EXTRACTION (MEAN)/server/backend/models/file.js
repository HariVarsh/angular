const mongoose = require("mongoose");
const fileSchema = mongoose.Schema({
    userId: { type: String, required: true },
    clientId: { type: String, required: true },
    doc: { type: String, required: true },
    ent: { type: String, required: true },
    filePath: { type: String, required: true },
    timeStamp: { type: String, required: true }
});
module.exports = mongoose.model("File", fileSchema);