const mongoose = require('mongoose');
const Subtype=require('./subtype');
const propertySchema = mongoose.Schema({
  propertyName: { type: String, required: true },
  subtype:{type:mongoose.Schema.Types.Mixed,ref:Subtype,default:""}
});

module.exports = mongoose.model('Property', propertySchema);
