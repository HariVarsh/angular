const mongoose = require('mongoose');

const uploadSchema = mongoose.Schema({
  userId: { type: String, required: true },
  blob:{type:String,required:true},
});

module.exports = mongoose.model('Upload', uploadSchema);
