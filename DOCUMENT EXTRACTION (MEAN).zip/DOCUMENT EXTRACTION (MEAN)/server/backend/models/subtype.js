const mongoose = require('mongoose');

const subtypeSchema = mongoose.Schema({
  name: { type: String, required: true },
  datatype:{type:String,required:true}
});

module.exports = mongoose.model('Subtype', subtypeSchema);
