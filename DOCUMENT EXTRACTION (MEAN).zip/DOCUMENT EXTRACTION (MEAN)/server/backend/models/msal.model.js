const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = Schema({
  email:String,
  role:{type:String,default:'User'},
  token:{type:String,default:''},
  clientId:{type:String,default:""}
})
module.exports=msalUser=mongoose.model('msalUser',userSchema)
