const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
  userId:{type:String,required:true},
  name: { type: String, required: true },
  role: {type:Number,required:true},
  clientId:{type:String,required:true}
});

module.exports = mongoose.model('User', userSchema);
