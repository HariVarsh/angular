const clientDao = require('../dao/client.dao');
const mail = require('../messageProto');

function GetClients() {
    return new Promise((resolve, reject) => {
        clientDao.GetClients().then(data => {
            resolve({code: 200, status: true, body: data, message: "Clients fetched successfully"});
        }).catch(err => {
            reject({code: 400, status: false, body: err, message: "Error getting clients"});
        });
    });
} 

function GetClient(req){
    return new Promise((resolve,reject)=>{
        clientDao.GetClient(req).then(data => {
            resolve({code: 200, status: true, body: data, message: "Client fetched successfully"});
        }).catch(err => {
            reject({code: 400, status: false, body: err, message: "Error getting client"});
        });
    });
}

function AddClient(req){
    return new Promise((resolve,reject)=>{
        clientDao.AddClient(req).then(data => {
            mail.Send(data.email, 'Client Registered', data.name + ' Congrats,\nYou have been successfully registered for docExtract');
            resolve({code: 200, status: true, body: data, message: "Client added successfully"});
        }).catch(err => {
            reject({code: 400, status: false, body: err, message: "Error adding client"});
        });
    });
}

function UpdateClient(req){
    return new Promise((resolve,reject)=>{
        clientDao.UpdateClient(req).then(data => {
            resolve({code: 200, status: true, body: data, message: "Client updated successfully"});
        }).catch(err => {
            reject({code: 400, status: false, body: err, message: err.message});
        });
    });
}

function DeleteClient(req){
    return new Promise((resolve,reject)=>{
        clientDao.DeleteClient(req).then(data => {
            mail.Send(data.email, 'Client Removed', data.name + ' Thank you for using docExtract\nHope to see you soon');
            clientDao.UpdateUsers(req);
            resolve({code: 200, status: true, body: data, message: "Client deleted successfully"});
        }).catch(err => {
            reject({code: 400, status: false, body: err, message: "Error deleting client"});
        });
    });
}

module.exports = {
    GetClient,
    GetClients,
    AddClient,
    UpdateClient,
    DeleteClient
}