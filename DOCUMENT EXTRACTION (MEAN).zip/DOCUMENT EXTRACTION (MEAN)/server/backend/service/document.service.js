const documentDao=require('../dao/document.dao');

function getClientDocuments(req)
{
    return new Promise((resolve,reject)=>{
       documentDao.getClientDocuments(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Documents fetched successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error Getting documents for clients"
                    });
                  });
    })
    
}

function removeDocumentType(req)
{
    return new Promise((resolve,reject)=>{
       documentDao.removeDocumentType(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Document Type removed successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error deleting document type"
                    });
                  });
    })
    
}

function addDocumentType(req)
{
    return new Promise((resolve,reject)=>{
       documentDao.addDocumentType(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Document Type added successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error adding document type"
                    });
                  });
    })
    
}
module.exports={
    getClientDocuments,
    removeDocumentType,
    addDocumentType
}