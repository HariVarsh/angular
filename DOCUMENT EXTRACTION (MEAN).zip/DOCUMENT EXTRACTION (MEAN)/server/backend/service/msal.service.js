const jwt = require('jsonwebtoken');
const dao = require('../dao/msal.dao');
const MsalUser =require('./../models/msal.model');
const epoch = require('unix-timestamp');
const constantConfigs=require('./../config/msal.config');
global.NewUserAdded=0;
async function verifyToken(token){
  NewUserAdded=0;
  console.log('yahi hai ')
  console.log(token);

  var accessTokenData=  jwt.decode(token);
  console.log(accessTokenData);
  return new Promise(async (resolve,reject)=>{


    var userEmail = accessTokenData.unique_name;
    var notValidBefore= epoch.toDate(accessTokenData.nbf);
    var expireAt=epoch.toDate(accessTokenData.exp)
    var currentDate= new Date();
    var timeDiff = expireAt - currentDate;
    userEmailToken= accessTokenData.unique_name;

    if(timeDiff >=0 && accessTokenData.iss === constantConfigs.issuer && accessTokenData.aud===constantConfigs.audience){
      dao.checkUserInDb(userEmailToken).then(
        async data=>{
          if(data===null)
          await userAdd(userEmailToken);
          console.log(NewUserAdded);
          NewUserAdded=1;
        }
      ).catch(
        err=>{
          console.log(err);
        }
      );
      var accessTokens= token;

      var UserData = new MsalUser({
        email:userEmailToken,
        token:accessTokens
      })
      await dao.saveToken(UserData);
      if(NewUserAdded===0)
      {
        dao.GetRole(userEmailToken).then(data=>{
          console.log(data);
          resolve({
            code:201,
            message:data.role
          })
        })
      }
      else{
        resolve({
          code:201,
          message:'User'
        })
      }
    }
    else{
      reject({
        code:404,
        message:'Invalid token'
      });
    }
  });
}

function userAdd(){
  dao.addUserToDb(new MsalUser({
    email:userEmailToken,
    role:'User'
  }));
}
module.exports={
  verifyToken
}
