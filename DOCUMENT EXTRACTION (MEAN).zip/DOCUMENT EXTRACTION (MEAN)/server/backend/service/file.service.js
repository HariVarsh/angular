const fileDao = require('../dao/file.dao');
const path = require('path');
const multer = require("multer");
const fs = require("fs");
const azure = require('azure-storage');
const File = require("../models/file");
var isUploaded = false;
const folderName = '/Windows/Temp/Assets/';
var container = "uploads3";
var file;
const MIME_TYPE_MAP = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "application/pdf": "pdf"
};
if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config();
}
var blobService = azure.createBlobService();
const createContainer = async (containerName) => {
    return new Promise((resolve, reject) => {
        blobService.createContainerIfNotExists(containerName, { publicAccessLevel: 'blob' }, err => {
            if (err) {
                reject(err);
            } else {
                resolve({ message: `Container '${containerName}' created` });
            }
        });
    });
};

const uploadLocalFile = async (containerName, filePath) => {
    return new Promise((resolve, reject) => {
        const fullPath = path.resolve(filePath);
        const blobName = path.basename(filePath);
        blobService.createBlockBlobFromLocalFile(containerName, blobName, fullPath, err => {
            if (err) {
                reject(err);
            } else {
                resolve({ message: `Local file "${filePath}" is uploaded` });

            }
        });
    });
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        console.log(file);

        try {
            if (!fs.existsSync(folderName)) {
                fs.mkdirSync(folderName);
            }
        } catch (error) {
            console.log(error);

        }
        try {
            const isValid = MIME_TYPE_MAP[file.mimetype];
            if (!isValid) {
                throw new InvalidMimeType("Invalid Mime Type");
            }
            cb(null, folderName);
        } catch (error) {
            console.log(error.message);


        }
    },
    filename: (req, file, cb) => {
        const ext = file.originalname.toLowerCase().split(".");
        const name = ext[0] + Date.now() + "." + ext[1]
            .split(" ")
            .join("-");
        cb(null, name);
    }
});

const execute = async () => {
    await createContainer(container);
    console.log(`Container "${container}" is created`);
    response = await uploadLocalFile(container, img);

    console.log(response.message);
}
function saveFile(req) {
    console.log(req.body);
    
    console.log(req.file);
    
    img = folderName+req.file.filename;
    execute().then(() => {
        fs.unlinkSync(folderName + req.file.filename);
        // console.log("dfghjklfghjkl");
        
        isUploaded = true;
        let date_ob = new Date();
        // file = new File({
        //     userId: req.body.userId,
        //     clientId: req.body.clientId,
        //     doc: req.body.documentName,
        //     ent: req.body.entityName,
        //     filePath: "https://documenttermextractionte.blob.core.windows.net/uploads2/" + req.file.filename,
        //     timeStamp: ("0" + date_ob.getDate()).slice(-2) + "-" + ("0" + (date_ob.getMonth() + 1)).slice(-2) + "-" + date_ob.getFullYear() + " " + date_ob.getHours() + ":" + date_ob.getMinutes() + ":" + date_ob.getSeconds()
        // });
        
        
    }).catch(err=>{
        console.log("err",err);
        
    })
        return new Promise((resolve, reject) => {
            console.log("dfghjfgjfg");
            
            fileDao.saveFile(req).then(data => {
                console.log("data",data);
                
                resolve({
                    code: 200,
                    status: true,
                    body: data,
                    message: "posts added"
                });
            }).catch(err => {
                console.log("err",err);
                
                reject({
                    code: 400,
                    status: false,
                    body: err,
                    message: "error adding post"
                });
            });
        })
    


}
function getTotalPosts(userId) {
    return new Promise((resolve, reject) => {
        fileDao.getTotalPosts(userId).then(
            data => {
                resolve({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Posts fetched successfully"
                });
            }).catch(err => {
                reject({
                    code: 400,
                    status: false,
                    bosy: err,
                    message: "Error in fetching data"
                });
            });
    })
}
function getUserHistory(userId, pageSize, currentPage) {
    return new Promise((resolve, reject) => {
        fileDao.getUserHistory(userId, pageSize, currentPage).then(
            data => {
                console.log(data);


                resolve({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Data Fetched Successfully"
                });
            })
            .catch(err => {
                reject({
                    code: 400,
                    status: false,
                    body: err,
                    message: "Error getting user data"
                });
            });
    })
}
module.exports = {
    getUserHistory,
    getTotalPosts,
    saveFile
}