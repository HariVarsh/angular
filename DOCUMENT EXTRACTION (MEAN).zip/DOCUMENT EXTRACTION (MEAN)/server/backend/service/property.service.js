const propertyDao=require('../dao/property.dao');

function deleteProperty(req)
{
    return new Promise((resolve,reject)=>{
      propertyDao.deleteProperty(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Document Property removed successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error deleting property !"
                    });
                  });
    })
    
}
function addProperty(req)
{
    return new Promise((resolve,reject)=>{
      propertyDao.addProperty(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Document Property added successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error adding property !"
                    });
                  });
    })
    
}
function addSubtype(req)
{
    return new Promise((resolve,reject)=>{
      propertyDao.addSubtype(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Subtype added successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error adding subtype !"
                    });
                  });
    })
    
}
function removeSubtype(req)
{
    return new Promise((resolve,reject)=>{
      propertyDao.removeSubtype(req).then(
            data => {
                  resolve ({
                    code: 200,
                    status: true,
                    body: data,
                    message: "Subtype removed successfully"
                  });
                })
                .catch(err => {
                    reject({
                      code: 400,
                      status: false,
                      body: err,
                      message: "Error removing subtype !"
                    });
                  });
    })
    
}
module.exports={
    deleteProperty,
    addProperty,
    addSubtype,
    removeSubtype
}
