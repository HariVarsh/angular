const userDao = require('../dao/user.dao');
function getUserByEmail(userEmail) {
  return new Promise((resolve, reject) => {
    userDao.getUserByEmail(userEmail).then(
      data => {
        resolve({
          code: 200,
          status: true,
          body: data,
          message: "Users fetched successfully"
        });
      }).catch(err => {
        reject({
          code: 400,
          status: false,
          body: err,
          message: "Error Getting users"
        });
      })

  })
}
function getUsers() {
  return new Promise((resolve, reject) => {
    userDao.getUsers().then(
      data => {
        resolve({
          code: 200,
          status: true,
          body: data,
          message: "Users fetched successfully"
        });
      })
      .catch(err => {
        reject({
          code: 400,
          status: false,
          body: err,
          message: "Error Getting users"
        });
      });
  })

}

function updateUser(req) {
  return new Promise((resolve, reject) => {
    userDao.updateUser(req).then(
      data => {
        // console.log(JSON.stringify(data)+".........");

        resolve({
          code: 200,
          status: true,
          body: data,
          message: "User updated for client!!"
        });
      })
      .catch(err => {
        reject({
          code: 400,
          status: false,
          body: err,
          message: "Error updating user"
        });
      });
  })

}
module.exports = {
  getUsers,
  updateUser,
  getUserByEmail
}