const mongoose = require('mongoose');
var Property=require("./Property");
                        
const documentTypeSchema = mongoose.Schema({
 id:{type:mongoose.Schema.Types.ObjectId},
 documentTypeName: {type:String,required:true},
 properties:{type:mongoose.Schema.Types.Mixed,ref:Property,required:true}

});

module.exports = mongoose.model('DocumentType', documentTypeSchema);
 