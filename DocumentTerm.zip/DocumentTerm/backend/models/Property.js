const mongoose = require('mongoose');

const propertySchema = mongoose.Schema({
  propertyName: { type: String, required: true },
  subtype:[{type:String,default:""}]
});

module.exports = mongoose.model('Property', propertySchema);
 