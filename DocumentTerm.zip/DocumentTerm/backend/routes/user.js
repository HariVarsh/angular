
const express = require("express");
const User=require("../models/user");
const router = express.Router();

router.get("/retrieve",(req,res,next) =>
{
  
  User.find().then(documents => {
    res.status(200).json({
      message: "Posts fetched successfully!",
      users: documents
    });
  });
});

router.post("/update",(req,res,next)=>
{
  User.update(
       { _id: req.body._id },
       { $set:
          {
            clientId:req.body.clientId
          }
       },()=>{}

    ) 
  res.status(200).json({
    message: "User updated for client",
    employee:req.body
  })
})

module.exports = router;