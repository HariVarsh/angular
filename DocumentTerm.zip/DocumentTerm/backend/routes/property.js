const express = require("express");
const DocumentType=require("../models/documentType")
const Document=require("../models/document");
const prouter = express.Router();

prouter.get("/:id",(req,res,next)=>
{
    console.log(req.params.id);
    console.log(Document.documentTypes);
    
Document.find({documentTypes:{$elemMatch:{documentTypeName:"EmployeeFinancial"}}}).then(doc=>{

    res.send(doc)});

    
    
})
module.exports=prouter;