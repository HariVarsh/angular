
const express = require("express");
const Client=require("../models/client");
const router = express.Router();

router.get("/",(req,res,next)=>
{
  Client.find().then(data=>{
    res.status(200).json({
      clients:data
    });
  });
});

module.exports=router;