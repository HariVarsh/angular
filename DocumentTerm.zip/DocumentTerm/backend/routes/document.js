
const express = require("express");
const Document = require("../models/document");
const DocumentType = require("../models/documentType")
const router = express.Router();
const propertyRoutes = require("./property");






router.get("/", (req, res, next) => {
  const document = new Document({
    documentName: "Travel",
    clientId: "5da5b13d068b68e9f5d2e14d",
    documentTypes: [{
      documentTypeName: "Flight",
      properties: [{
        propertyName: "Company"
      },
      {
        propertyName: "Places",
        subtype: ["Source", "Destination"]
      }]
    },
    {
      documentTypeName: "Train",
      properties: [{
        propertyName: "Price"
      },
      {
        propertyName: "Places",
        subtype: ["From", "To"]
      }]
    }
    ]
  });
  document.save();
  res.send(document);
});


router.get("/:id", (req, res, next) => {
  Document.find({

    clientId: req.params.id
  })
    .then(doc => {
      res.send(doc)

    })
});

router.post("/removeType/:did", (req, res, next) => {
  console.log(req.params.did);
  console.log(req.body);

  Document.update({ _id: req.params.did }, { $pull: { documentTypes: { documentTypeName: req.body.documentTypeName, properties: req.body.properties } } }, () => { }).then(doc => {
    res.status(200).json({
      message: "deleted",
      documents: doc
    })
  })

})

router.post("/addType/:did", (req, res, next) => {
  console.log(req.body);

  const newEntity = new DocumentType(
    {
      documentTypeName: req.body.documentType,
      properties: []
    })
  console.log(newEntity);

  Document.findOneAndUpdate({ _id: req.params.did }, { $addToSet: { documentTypes: newEntity } }, (err, data) => { }).then(doc => {
    res.send(doc)
  })

})
router.use("/property", propertyRoutes);
module.exports = router;