import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersModule } from './users/users.module';
import { TermsModule } from './terms/terms.module';
import { PropertiesModule } from './properties/properties.module';
import { HeaderComponent } from './header/header.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UsersModule,
    TermsModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
