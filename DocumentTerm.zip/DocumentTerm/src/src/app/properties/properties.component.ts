import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PropertyService } from '../service/property.service';
import { DocumentService } from '../service/document.service';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';

@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.css']
})
export class PropertiesComponent implements OnInit {

  @Input('entityReceived') entityReceived;
  docTypeId:any;
  allEntity:any;
  entity:any=null;
  property=[];
  addPropertyForm:FormGroup;
  constructor(private activatedRoute:ActivatedRoute,private propertyService:PropertyService,
    private docService:DocumentService,private fb:FormBuilder) 
  { this.addPropertyForm = fb.group({
    'property': [null, Validators.required]
  }) }
  ngOnInit() {
   
    this.docTypeId=this.activatedRoute.params['_value'].id;
    this.getAllProperties(this.docTypeId);
    
  }

  getAllProperties(dtid:any)
  {
   this.allEntity=this.docService.getProperty();    
   this.allEntity.documentTypes.forEach(element => {
     if(element._id==dtid)
     {  this.entity=element
       this.property=element.properties
     }
   });
   console.log(this.property);
   
   
  }


}
