import { Component, OnInit } from '@angular/core';
import { ClientService } from '../service/client.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UsersService } from '../service/users.service';
import { DocumentService } from '../service/document.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {
  clients: any = [];
  documents = [];
  client_documents = [];
  clientIdValue: any = null;
  documentIdValue:any =null;
  is_Present: boolean = false;
  documentType:any;
  addDocTypeForm:FormGroup
  constructor(private clientService: ClientService,
    private documentService: DocumentService,private fb:FormBuilder, private router:Router) { 
      this.addDocTypeForm = fb.group({
        'documentType': [null, Validators.required]
      })
    }

  ngOnInit() {
    this.clientService.getClients().subscribe(data => {
      this.setClient(data);

    });
  }
  setClient(data: any) {
    this.clients = data.clients;
    //console.log(this.clients); 
  }


  checkDocuments() {
    this.is_Present = false
    this.clientIdValue = document.getElementById("clientDoc")['value'];
    this.client_documents.forEach(element => {
      if (element.clientId == this.clientIdValue) {
      this.is_Present = true
        this.showDocuments(this.clientIdValue);
      }
    });

    if (this.is_Present == false) {
      this.documentService.getClientDocument(this.clientIdValue).subscribe(data => {
        for (var i = 0; i < (data['length']); i++) {
          this.client_documents.push(data[i]);
        }



        //this.client_documents=this.client_documents+data;
        this.showDocuments(this.clientIdValue)
      })
    }
  }

  showDocuments(clientIdValue: any) {
    this.documents = []
    this.documentIdValue=null;
    this.client_documents.forEach(element => {

      if (element.clientId == clientIdValue) {
        this.documents.push(element)
      }


    });
    //this.entityTypes=this.documents
    console.log(this.documents);

  }
  showDocumentTypes()
  {
  this.documentIdValue=document.getElementById("document")['value'];
  this.documents.forEach(element => {
    if(element._id==this.documentIdValue)
    {this.documentType=element;
      }
  });
  console.log(this.documentType.documentTypes);
  
  }
  addDocType(newEntity:any,documentIdValue:any)
  {
    this.documentService.addEntity(newEntity,documentIdValue).subscribe(data=>{
      console.log(data['documentTypes']);
      this.documentType.documentTypes=data['documentTypes'];
      this.showDocumentTypes();
    })
    
  }
  removeType(type:any,documentType:any)
  {
     console.log(type);
     var index=this.documentType.documentTypes.indexOf(type);
     console.log(index);
     
     this.documentType.documentTypes.splice(index,1);
     this.showDocumentTypes();
    
    this.documentService.removeDocumentType(type,documentType._id).subscribe(data=>{
      console.log(data);
      
    })
    
  }

openProperties(type:any,allDocTypes:any)
{
  this.documentService.setProperty(allDocTypes);

  this.router.navigate(["/properties", type._id]);
}
}
