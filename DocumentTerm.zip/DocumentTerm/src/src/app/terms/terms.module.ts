import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermsComponent } from './terms.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PropertiesModule } from '../properties/properties.module';


@NgModule({
  declarations: [TermsComponent],
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    HttpClientModule,
    PropertiesModule
  ]
})
export class TermsModule { }
