import { Component, OnInit } from '@angular/core';
import { ClientService } from '../service/client.service';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UsersService } from '../service/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  clients: any = [];
  users: any = [];
  client_users = [];
  optionValue = null;
  addUserForm: FormGroup
  constructor(private clientService: ClientService, private userService: UsersService,
    private fb: FormBuilder) {
    this.addUserForm = fb.group({
      'Mid': [null, Validators.required]
    })
  }

  ngOnInit() {
    this.clientService.getClients().subscribe(data => {
      this.setClient(data);
      this.setUsers()
    })

  }

  setUsers() {
    this.userService.getUsers().subscribe(data => {
      this.users = data['users']
      console.log(this.users);
    });
  }
  setClient(data: any) {
    this.clients = data.clients;
    //console.log(this.clients); 
  }
  showUsers() {
    this.client_users = []
    this.optionValue = document.getElementById("client")['value'];
    for (var i in this.users) {
      if (this.users[i].clientId == this.optionValue) {
        this.client_users.push(this.users[i])
        // console.log(this.client_users);  
      }

    }
  }

  removeUser(user: any) {
    console.log("first" + user);

    this.userService.deAssociateUser(user).subscribe(data => {
      console.log(user);

      const updatedUser = this.client_users.filter(clientUser => clientUser.clientId !== user.clientId);
      this.client_users = updatedUser;
      console.log(data);

    });

  }
  flag = 0
  employee: any

  addUser(mid: any, optionValue: any) {

    this.employee = {};
    this.flag = 0;
    console.log(mid.Mid + "  " + optionValue);

    this.users.forEach(element => {

      if ((element.userId == mid.Mid) && (element.clientId == "")) {
        this.flag = 1;
        this.employee = element
      }
    });
    console.log(this.flag);

    if (this.flag == 1) {
      this.userService.associateUser(this.employee, optionValue).subscribe(data => {
        //console.log(user);
        this.client_users.push(data['employee'])
        console.log(data);

      });
    }
    else{
      alert("User already associated with another client")
    }
  }
}
