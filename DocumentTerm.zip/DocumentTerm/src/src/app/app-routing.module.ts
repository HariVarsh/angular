import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { TermsComponent } from './terms/terms.component';
import { PropertiesComponent } from './properties/properties.component';

const routes: Routes = [
  {
  path:"users",
  component:UsersComponent
},
  {
    path:"terms",
    component:TermsComponent
  },
 { path:"properties/:id",
component:PropertiesComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
