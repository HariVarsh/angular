import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PropertyService {

  getAllUrl="http://localhost:3000/api/document/property/"
  constructor(private http:HttpClient) { }

  getAll(docTypeId:any)
  {
    return this.http.get(this.getAllUrl+docTypeId);
  }
}
