import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { }

  userUrl="http://localhost:3000/api/user/retrieve"
  updateUrl="http://localhost:3000/api/user/update"
  getUsers()
  {
    return this.http.get(this.userUrl);
  }

  deAssociateUser(user:any)
  {
    user.clientId="";
    console.log(user);
   return this.http.post(this.updateUrl,user,httpOptions)
    
  }
  associateUser(employee:any,client:any)
  {
    employee.clientId=client;
    console.log(employee);
    return this.http.post(this.updateUrl,employee,httpOptions)
    
  }
}
