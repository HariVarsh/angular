import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class DocumentService {
  allDocTypes:any
  getDocumentUrl="http://localhost:3000/api/document/"
  removeDocType="http://localhost:3000/api/document/removeType/"
  addDocTypeUrl="http://localhost:3000/api/document/addType/"
  constructor(private http:HttpClient) { }

  getClientDocument(clientIdValue:any)
  {
    return this.http.get(this.getDocumentUrl+clientIdValue);
  }

  addEntity(newEntity:any,did:any)
  {

    return this.http.post(this.addDocTypeUrl+did,newEntity,httpOptions)
  }
  removeDocumentType(type:any,did:any)
  {    
    return this.http.post(this.removeDocType+did,type,httpOptions)
  }

  setProperty(allDocTypes:any)
  {
    this.allDocTypes=allDocTypes  
  }

  getProperty()
  {
    return this.allDocTypes;
  }
}
