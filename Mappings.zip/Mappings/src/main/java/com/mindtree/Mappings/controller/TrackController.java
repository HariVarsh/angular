package com.mindtree.Mappings.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Mappings.entity.Capability;
import com.mindtree.Mappings.entity.Track;
import com.mindtree.Mappings.exceptions.MyApplicationException;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.service.TrackService;

@RestController
@RequestMapping("/track")
public class TrackController {
	@Autowired
	TrackService trackService;

	@PostMapping("")
	public void add(@RequestBody Track track) {
		try {
			trackService.add(track);
		} catch (MyServiceException e) {
			throw new MyApplicationException(e.getMessage());
		}
	}

	@PutMapping("/{id}/{name}")
	public void update(@PathVariable("id") int id, @PathVariable("name") String name) {
		try {
			trackService.update(id, name);
		} catch (MyServiceException e) {
			throw new MyApplicationException(e.getMessage());
		}

	}

	@DeleteMapping("/{id}")
	public void delete(@PathVariable("id") int id) {
		try {
			trackService.delete(id);
		} catch (MyServiceException e) {
			throw new MyApplicationException(e.getMessage());
		}

	}

	@GetMapping("/track/getAllTracks")
	public List<Track> getAllTracks() {

		return trackService.getAllTracks();

	}
	@GetMapping("/{id}")
	public List<Capability> getCapability(@PathVariable("id") int id){
		System.out.println("from cntroller:"+ id);
		return trackService.getCapability(id);
		
	}
//	@GetMapping("/track/getMind/{id}")
//	public List<String> getMind(@PathVariable("id") int id){
//		return trackService.getMinds(id);
//		
//	}

}
