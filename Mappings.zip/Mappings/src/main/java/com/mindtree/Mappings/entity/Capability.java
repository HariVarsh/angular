package com.mindtree.Mappings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Capability {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int capabilityID;
	@Column(unique = true)
	String capability_name;

	@ManyToOne
	@JoinColumn(name = "trak_id")

	Track track;

	public Capability(String capability_name, Track track) {
		super();
		this.capability_name = capability_name;
		this.track = track;
	}

	public Capability() {

	}

	public int getCapabilityID() {
		return capabilityID;
	}

	public void setCapabilityID(int capabilityID) {
		this.capabilityID = capabilityID;
	}

	public String getCapability_name() {
		return capability_name;
	}

	@Override
	public String toString() {
		return "Capability [capabilityID=" + capabilityID + ", capability_name=" + capability_name + ", track=" + track
				+ "]";
	}

	public void setCapability_name(String capability_name) {
		this.capability_name = capability_name;
	}

	public Track getTrack() {
		return track;
	}

	public void setTrack(Track track) {
		this.track = track;
	}

}
