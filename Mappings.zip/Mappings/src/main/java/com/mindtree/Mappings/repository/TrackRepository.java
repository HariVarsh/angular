package com.mindtree.Mappings.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.Mappings.entity.Minds;
import com.mindtree.Mappings.entity.Track;
@Repository
public interface TrackRepository extends JpaRepository<Track, Integer> {

	@Transactional
	@Modifying
	@Query("update Track set trackName=?2 where trackId=?1")
	void update(int id, String name);
	
	@Query("from Track where trackId=?1")
	Track findById(int i);

	
}
