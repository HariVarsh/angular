package com.mindtree.Mappings.service;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Mappings.entity.Capability;
import com.mindtree.Mappings.entity.Track;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.exceptions.RecordAlreadyExistsException;
import com.mindtree.Mappings.exceptions.RecordNotFoundException;
import com.mindtree.Mappings.repository.CapabilityRepository;
import com.mindtree.Mappings.repository.TrackRepository;

@Service
public class CapabilityService {
	@Autowired
	CapabilityRepository capabilityRepository;

	@Autowired
	TrackRepository trackRepository;

	public void addCapability(Capability capability, int id) {
		Track track = trackRepository.findById(id);
		int i = track.getTrackId();
		System.out.println(i);
		try {
			/*
			 * getting the list of tracks and checking if the user entered trackID exists in
			 * it. if exists, get the track name.
			 */
			List<Track> trackList = trackRepository.findAll();
			Track t = trackList.stream().filter(x -> id == i).findAny()
					.orElseThrow(() -> new RecordNotFoundException("enter valid id"));
			/*
			 * getting list of capability, if the user entered capName is already
			 * present,throw an exception
			 */

			List<Capability> capList = capabilityRepository.findAll();
			Capability c = capList.stream()
					.filter(x -> x.getCapability_name().equalsIgnoreCase(capability.getCapability_name())).findAny()
					.orElse(null);
			/*
			 * if all above conditions are done, the track name is set to capability
			 */
			if (c == null) {
				capability.setTrack(t);
				capabilityRepository.save(capability);
			} else
				throw new RecordAlreadyExistsException("this record already exists ");
		} catch (RecordAlreadyExistsException e) {
			throw new MyServiceException("two capabilities cannot have same name");
		}
	}

	public List<Capability> getCapabilityByTrack(String name) {
		List<Capability> capList = capabilityRepository.findAll();
		try {
			if (!capList.stream().anyMatch(i -> i.getTrack().getTrackName().equalsIgnoreCase(name)))
				throw new RecordNotFoundException("there's no capability under this track");
			else
				return capList.stream().filter(i -> i.getTrack().getTrackName().equalsIgnoreCase(name))
						.collect(Collectors.toList());
		} catch (RecordNotFoundException e) {
			throw new MyServiceException("input valid track-there's no capability under this track");
		}

	}

}
