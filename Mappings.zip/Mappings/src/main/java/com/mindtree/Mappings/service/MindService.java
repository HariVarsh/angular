package com.mindtree.Mappings.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Mappings.entity.Minds;
import com.mindtree.Mappings.entity.Track;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.exceptions.RecordAlreadyExistsException;
import com.mindtree.Mappings.exceptions.RecordNotFoundException;
import com.mindtree.Mappings.repository.MindRepository;
import com.mindtree.Mappings.repository.TrackRepository;

@Service
public class MindService {
	@Autowired
	MindRepository mindRepository;

	@Autowired
	TrackRepository trackRepository;

	public void add(Minds minds) throws MyServiceException {
		Track track = new Track();
		track = minds.getTrack();
		int i = track.getTrackId();

		try {
			List<Track> trackList = trackRepository.findAll();
			// get mind list and compare the track id. if user given mid is already present
			// throw exception
			List<Minds> mindlist = mindRepository.findAll();
			System.out.println();
			if (mindlist.stream().anyMatch(x -> x.getMid().equalsIgnoreCase(minds.getMid()))) {
				throw new RecordAlreadyExistsException("this mind already existss");
			} // no comming
			Track t = trackList.stream().filter(track1 -> track1.getTrackId() == i).findAny()
					.orElseThrow(() -> new RecordNotFoundException("enter valid id"));
			minds.setTrack(t);
			mindRepository.save(minds);
		} catch (RecordNotFoundException e) {
			throw new MyServiceException("this id is invalid");
		} catch (RecordAlreadyExistsException e) {
			throw new MyServiceException(e);
		}

	}

	public List<Minds> getMindsByTrack(String name) {
		List<Minds> mindList = mindRepository.findAll();

		return mindList.stream().filter(i -> i.getTrack().getTrackName().equalsIgnoreCase(name))
				.collect(Collectors.toList());

	}
}
