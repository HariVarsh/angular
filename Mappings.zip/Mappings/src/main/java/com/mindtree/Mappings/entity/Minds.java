package com.mindtree.Mappings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Minds {
	@Id
	private String mid;
	@Column(unique=true)
	private String mind_name;
	@OneToOne
	@JoinColumn(name = "track_id")
	private Track track;
	public Minds(String mid, String mind_name, Track track) {
		super();
		this.mid = mid;
		this.mind_name = mind_name;
		this.track = track;
	}
	public Minds() {
		
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMind_name() {
		return mind_name;
	}
	public void setMind_name(String mind_name) {
		this.mind_name = mind_name;
	}
	public Track getTrack() {
		return track;
	}
	public void setTrack(Track track) {
		this.track = track;
	}
	
}
