package com.mindtree.Mappings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class NonKo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	int nonko_Id;
	String nonko_Description;
	@ManyToOne
	@JoinColumn(name="capId")
	Capability capability;
	public int getNonko_Id() {
		return nonko_Id;
	}
	public void setNonko_Id(int nonko_Id) {
		this.nonko_Id = nonko_Id;
	}
	public String getNonko_Description() {
		return nonko_Description;
	}
	public void setNonko_Description(String nonko_Description) {
		this.nonko_Description = nonko_Description;
	}
	public Capability getCapability() {
		return capability;
	}
	public void setCapability(Capability capability) {
		this.capability = capability;
	}
	public NonKo(int nonko_Id, String nonko_Description, Capability capability) {
		super();
		this.nonko_Id = nonko_Id;
		this.nonko_Description = nonko_Description;
		this.capability = capability;
	}
	
}
