package com.mindtree.Mappings.exceptions;

public class MyServiceException extends MyApplicationException {

	public MyServiceException(String msg) {
		super(msg);
	}

	public MyServiceException(RecordAlreadyExistsException e) {
		super(e);
	}

}
