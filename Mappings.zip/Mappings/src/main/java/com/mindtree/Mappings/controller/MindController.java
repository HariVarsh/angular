package com.mindtree.Mappings.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Mappings.entity.Minds;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.service.MindService;

@RestController
public class MindController {
	@Autowired
	MindService mindService;

	@PostMapping("/mind/add")
	public void add(@RequestBody Minds minds) {
		try {
			mindService.add(minds);
		} catch (MyServiceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@GetMapping("/mind/getMinds/{name}")
	public List<Minds> getMindsByTrack(@PathVariable("name") String name){
		
		return mindService.getMindsByTrack(name);
		
	}
	
	
	
	
}
