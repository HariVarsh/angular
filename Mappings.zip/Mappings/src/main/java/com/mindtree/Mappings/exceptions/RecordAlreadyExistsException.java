package com.mindtree.Mappings.exceptions;

public class RecordAlreadyExistsException extends MyServiceException{

	

	public RecordAlreadyExistsException(String string) {
		super(string);	}

}
