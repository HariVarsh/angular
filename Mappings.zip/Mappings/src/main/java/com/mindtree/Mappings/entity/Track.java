package com.mindtree.Mappings.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Track {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int trackId;
	@Column(unique = true)
	private String trackName;

	public int getTrackId() {
		return trackId;
	}

	public void setTrackId(int trackId) {
		this.trackId = trackId;
	}

	@Override
	public String toString() {
		return "Track [trackId=" + trackId + ", trackName=" + trackName + "]";
	}

	public String getTrackName() {
		return trackName;
	}

	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}

	public Track(String trackName) {
		super();

		this.trackName = trackName;
	}

	public Track() {

	}

	
	
	@OneToMany(mappedBy="track" )
	@JsonIgnore
	List<Capability> capability;

	public List<Capability> getCapability() {
		return capability;
	}

	public void setCapability(List<Capability> capability) {
		this.capability = capability;
	}
}
