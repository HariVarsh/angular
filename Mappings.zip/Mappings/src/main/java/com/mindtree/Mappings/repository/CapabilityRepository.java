package com.mindtree.Mappings.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.Mappings.entity.Capability;

public interface CapabilityRepository extends JpaRepository<Capability, Integer> {

}
