package com.mindtree.Mappings.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Mappings.entity.Capability;
import com.mindtree.Mappings.entity.Minds;
import com.mindtree.Mappings.entity.Track;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.exceptions.RecordAlreadyExistsException;
import com.mindtree.Mappings.exceptions.RecordNotFoundException;
import com.mindtree.Mappings.repository.MindRepository;
import com.mindtree.Mappings.repository.TrackRepository;

@Service
public class TrackService {
	@Autowired
	TrackRepository trackRepository;

	public void add(Track track) {
		try {

			List<Track> trackList = trackRepository.findAll();
			Track track1 = trackList.stream().filter(i -> i.getTrackName().equalsIgnoreCase(track.getTrackName()))
					.findAny().orElse(null);
			if (track1 == null) {
				trackRepository.save(track);
			} else {
				throw new RecordAlreadyExistsException("Cannot add this track");
			}

		} catch (RecordAlreadyExistsException e) {
			throw new MyServiceException("cannot add");
		}
	}

	public void update(int id, String name) throws MyServiceException {
		try {
			List<Track> trackList = trackRepository.findAll();
			Track track1 = trackList.stream().filter(i -> i.getTrackId() == id).findAny()
					.orElseThrow(() -> new RecordNotFoundException("this id doesnot exist"));
			System.out.println(track1);
			
				trackRepository.update(id, name);

		} catch (RecordNotFoundException e) {
			throw new MyServiceException("enter valid id");

		}

	}

	public void delete(int id)throws MyServiceException {
		try {
			List<Track> trackList = trackRepository.findAll();
			Track track1 = trackList.stream().filter(i -> i.getTrackId() == id).findAny()
					.orElseThrow(() -> new RecordNotFoundException("this id doesnot exist"));
			if (track1 != null)
				trackRepository.deleteById(id);
		} catch (RecordNotFoundException e) {
			throw new MyServiceException("enter valid id");

		}
	}

	public List<Track> getAllTracks() {

		return trackRepository.findAll();
	}

	public List<Capability> getCapability(int i) {
		System.out.println("from servicce:"+ i);

		Track track=trackRepository.findById(i);
		System.out.println(track);
		return track.getCapability();
	}

//	public List<String> getMinds(int i) {
//		List<String> mindList=new ArrayList<>();
//		Minds mind=MindRepository.findByIds(i);
//		mindList.add(mind.getMind_name());
//		return mindList;
//	}

}
