package com.mindtree.Mappings.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity

public class Ko {
	public Ko(int ko_Id, String ko_Description, Capability capability) {
		super();
		this.ko_Id = ko_Id;
		this.ko_Description = ko_Description;
		this.capability = capability;
	}

	public int getKo_Id() {
		return ko_Id;
	}

	public void setKo_Id(int ko_Id) {
		this.ko_Id = ko_Id;
	}

	public String getKo_Description() {
		return ko_Description;
	}

	public void setKo_Description(String ko_Description) {
		this.ko_Description = ko_Description;
	}

	public Capability getCapability() {
		return capability;
	}

	public void setCapability(Capability capability) {
		this.capability = capability;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int ko_Id;
	String ko_Description;
	@ManyToOne
	@JoinColumn(name = "capId")
	Capability capability;

}
