package com.mindtree.Mappings.exceptions;

public class RecordNotFoundException extends MyServiceException {

	public RecordNotFoundException(String string) {
		super(string);
	}

}
