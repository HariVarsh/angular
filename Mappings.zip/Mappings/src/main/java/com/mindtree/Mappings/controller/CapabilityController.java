package com.mindtree.Mappings.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Mappings.entity.Capability;
import com.mindtree.Mappings.exceptions.MyApplicationException;
import com.mindtree.Mappings.exceptions.MyServiceException;
import com.mindtree.Mappings.service.CapabilityService;

@RestController
public class CapabilityController {
	@Autowired
	CapabilityService capabilityService;

	@PostMapping("/capability/add/{id}")
	public void addCapability(@RequestBody Capability capability, @PathVariable("id") int id) {
		try {
			System.out.println("hi from cntrollr");
			System.out.println(id);
			capabilityService.addCapability(capability, id);
		} catch (MyServiceException e) {
			throw new MyApplicationException(e.getMessage());
		}

	}

	@GetMapping("/capability/getCapabilityByTrack/{name}")
	public ResponseEntity<?> getCapabilityByTrack(@PathVariable("name") String name) {
		try {
			HashMap<String,Object> result= new HashMap<String,Object>();
			result.put("status", HttpStatus.OK);
			result.put("success", true);
			result.put("body", capabilityService.getCapabilityByTrack(name));
			return ResponseEntity.status(HttpStatus.OK)
					.header("status", String.valueOf(HttpStatus.OK)).body(result);
		} catch (MyServiceException e) {
			HashMap<String,Object> result= new HashMap<String,Object>();
			result.put("status", HttpStatus.NOT_FOUND);
			result.put("success", false);
			result.put("message", "something went wrong");
			result.put("exception",e.getMessage());
			result.put("cause", e.getCause());
			return ResponseEntity.status(HttpStatus.OK)
					.header("status", String.valueOf(HttpStatus.NOT_FOUND)).body(result);
		}

	}

}
