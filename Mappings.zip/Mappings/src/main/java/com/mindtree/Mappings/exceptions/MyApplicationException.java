package com.mindtree.Mappings.exceptions;

public class MyApplicationException extends RuntimeException {

	public MyApplicationException(String message) {
		super(message);
	}
	

	public MyApplicationException(RecordAlreadyExistsException e) {
	}

}
