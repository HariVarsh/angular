package com.mindtree.Mappings.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.Mappings.entity.Minds;
@Repository
public interface MindRepository extends JpaRepository<Minds, Integer>  {

	
}
