import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class CapabilityService {
id

  private _display="../../assets/capability.json"

  constructor(private http:HttpClient) { }
  httpOption = { header: new HttpHeaders({ 'content-Type': 'application/json' }) }
  displayJson():Observable<any>{
    return this.http.get<any>(this._display)
  }


  getId(){
    return this.id;
  }
  setId(id){
    this.id=id;
  }
}





