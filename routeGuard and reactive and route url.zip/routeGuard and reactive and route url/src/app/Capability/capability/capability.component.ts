import { Component, OnInit } from '@angular/core';
import { CapabilityService } from '../capability.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-capability',
  templateUrl: './capability.component.html',
  styleUrls: ['./capability.component.css']
})
export class CapabilityComponent implements OnInit {
  data
  num;
  constructor(private capService: CapabilityService,private route:Router) { }

  ngOnInit() {
    this.capService.displayJson().subscribe(data => {
      this.data = data;
      
    });
  }
  onClick(x){
    this.num=0;
    console.log(x)
    this.capService.setId(x);
    this.route.navigate(['capId',x.capId]);
  }

}
