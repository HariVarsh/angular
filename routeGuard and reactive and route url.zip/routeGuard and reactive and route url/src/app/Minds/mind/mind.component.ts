import { Component, OnInit } from '@angular/core';
import { MindService } from '../mind.service';

@Component({
  selector: 'app-mind',
  templateUrl: './mind.component.html',
  styleUrls: ['./mind.component.css']
})
export class MindComponent implements OnInit {
  data
  dataArray=[]
  constructor(private mindService: MindService) { }

  ngOnInit() {
    this.mindService.displayJson().subscribe(data => {
      this.data = data;
    
    });

  }

}
