import { TestBed } from '@angular/core/testing';

import { MindService } from './mind.service';

describe('MindService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MindService = TestBed.get(MindService);
    expect(service).toBeTruthy();
  });
});
