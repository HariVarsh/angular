import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeadComponent } from './Lead/lead/lead.component';
import { MindComponent } from './Minds/mind/mind.component';
import { CapabilityComponent } from './Capability/capability/capability.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { GetcapabilitybyIDComponent } from './getcapabilityby-id/getcapabilityby-id.component'
@NgModule({
  declarations: [
    AppComponent,
    LeadComponent,
    MindComponent,
    CapabilityComponent,
    LoginComponent,
    HomeComponent,
    AccessDeniedComponent,
    GetcapabilitybyIDComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule, HttpClientModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
