import { Component, OnInit } from '@angular/core';
import { CapabilityService } from '../Capability/capability.service';
import { ActivatedRoute } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-getcapabilityby-id',
  templateUrl: './getcapabilityby-id.component.html',
  styleUrls: ['./getcapabilityby-id.component.css']
})
export class GetcapabilitybyIDComponent implements OnInit {
 capability= "../../assets/capability.json"
  capabilityID
  oneCapability=[]
  constructor(private capService: CapabilityService, private route: ActivatedRoute) { 
    this.capService.getId();
  }
  id

  ngOnInit() {
    this.route.params.subscribe(params => {
       console.log(params);
      this.capabilityID = params;
      console.log(this.capabilityID.id);
    })
   
    
  }

  //   this.id = this.capService.getId()
  //   for (let x = 0; x < data.length; x++) {
  //     if (data[x].capId == this.id)
  //       this.oneCapability.push(data[x])

  //   }
  // });
  

}
