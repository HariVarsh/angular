import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '../../../node_modules/@angular/router';
import { RoleService } from '../role.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuardService implements CanActivate {

  constructor(private roleService: RoleService, private route: Router) { }
  canActivate(route: ActivatedRouteSnapshot): boolean {
    if (this.roleService.getRole() == "mind")
       this.route.navigate(['denied']);
    

    else return true;
  }
}
