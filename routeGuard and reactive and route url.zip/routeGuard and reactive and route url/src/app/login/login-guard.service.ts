import { Injectable } from '@angular/core';
import { CanActivate, Router } from '../../../node_modules/@angular/router';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class LoginGuardService implements CanActivate {

  constructor(private loginService:LoginService,private route:Router) { }

  canActivate():boolean{
    if(this.loginService.getloginStatus){
      return true;
    }
    else this.route.navigate(['login']);
    
  }
}
