import { Component, OnInit } from '@angular/core';
import { RoleService } from '../role.service';
import { LoginService } from './login.service';
import { FormGroup, FormBuilder,Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] 
})
export class LoginComponent implements OnInit {
  select:string;
  myReactiveForm:FormGroup;
  constructor(private roleService: RoleService,private loginService: LoginService,private fb:FormBuilder) { }

  ngOnInit() {
    this.myReactiveForm=this.fb.group({
    mid:["",[Validators.required]],
    pwd:["",[Validators.required,Validators.minLength(8)]]
    });
  }
  checkRole() {
    console.log(this.select);
    this.roleService.setRole(this.select);
    this.loginService.setLoginStatus(true); 
  }

}
