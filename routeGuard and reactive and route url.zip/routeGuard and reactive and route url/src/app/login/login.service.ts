import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loginStatus
  constructor() { }
  getloginStatus() {
    return this.loginStatus;
  }
  setLoginStatus(status) {
    this.loginStatus = status
  }
}
