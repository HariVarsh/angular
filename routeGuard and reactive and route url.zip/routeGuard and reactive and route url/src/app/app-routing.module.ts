import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LeadComponent } from './Lead/lead/lead.component';
import { MindComponent } from './Minds/mind/mind.component';
import { CapabilityComponent } from './Capability/capability/capability.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { RoleGuardService } from './home/role-guard.service';
import { GetcapabilitybyIDComponent } from './getcapabilityby-id/getcapabilityby-id.component';


const routes: Routes = [
  {
    path:"",
    component:LoginComponent
  },
  {
  path: "home",
  component: HomeComponent
},{
  path:"lead",
  component:LeadComponent,
  canActivate:[RoleGuardService]
},
{
  path:"mind",
  component:MindComponent
},
{
  path: "capability",
  component:CapabilityComponent
},
{
  path:"denied",
  component:AccessDeniedComponent
},

{
  path:"capId/:id",
  component: GetcapabilitybyIDComponent
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
