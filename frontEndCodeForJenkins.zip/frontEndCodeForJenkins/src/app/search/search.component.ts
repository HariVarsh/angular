import { Component, OnInit } from '@angular/core';
import { TrackServiceService } from '../track-service.service';
import { Track } from '../Track';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  track:Track=new Track();
data;
  constructor(private service:TrackServiceService
  ) { }

  ngOnInit() {
  }
  onSubmit(){
   this.service.searchTrack(this.track.id).subscribe(data=>this.data=data);
  }

}
