export class Track {
    id: number;
    name: String;
    leadCount: number;
    campusMindCount: number;

} 