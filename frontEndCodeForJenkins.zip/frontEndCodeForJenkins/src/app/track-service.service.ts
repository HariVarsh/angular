import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Track } from 'src/app/Track';


@Injectable({
  providedIn: 'root'
})
export class TrackServiceService {
  track: Track = new Track();

  constructor(private http: HttpClient) { }

  private _create = "http://localhost:8080/addTrack";
  private _read = "http://localhost:8080/getAllTracks";
  private _update = "http://localhost:8080/updates";
  private _search = "http://localhost:8080/getTrack";
  private _delete = "http://localhost:8080/delete";
  httpOption = { header: new HttpHeaders({ 'content-Type': 'application/json' }) }
  id;
  insertTrack(track): Observable<Track> {
    alert("successfully inserted")
    return this.http.post<Track>(this._create, track);
  }
  displayTracks(): Observable<Track[]> {
    return this.http.get<Track[]>(this._read);
  }
  updateTracks(id, name): Observable<Track> {
    alert("updated successfully")
    return this.http.put<Track>(this._update + "/" + id + "/" + name, this.track)
  }
  searchTrack(id): Observable<Track> {
    alert("searched");
    console.log(id);
    return this.http.get<Track>(this._search + "/" + id);
  }
  deleteTrack(id): Observable<Track> {
    return this.http.delete<Track>(this._delete + "/" + id);
  }

}



