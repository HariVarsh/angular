import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateComponent } from './create/create.component';
import { ReadComponent } from './read/read.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [{path:'',redirectTo:'',pathMatch:'full'},

{path:'create', component:CreateComponent},
{path:'read', component:ReadComponent},      
{path:'update', component:UpdateComponent},
{path:'delete', component:DeleteComponent},
{path:'search', component:SearchComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
