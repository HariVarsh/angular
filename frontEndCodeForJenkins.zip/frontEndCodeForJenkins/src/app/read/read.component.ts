import { Component, OnInit } from '@angular/core';
import { TrackServiceService } from '../track-service.service';

@Component({
  selector: 'app-read',
  templateUrl: './read.component.html',
  styleUrls: ['./read.component.css']
})
export class ReadComponent implements OnInit {
  data;
  constructor(private service: TrackServiceService) { }

  ngOnInit() {
    this.service.displayTracks().subscribe(data1 => this.data = data1)
  }



}
