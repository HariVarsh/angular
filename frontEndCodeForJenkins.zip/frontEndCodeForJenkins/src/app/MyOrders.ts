import { Customer } from './Customer';

export class MyOrders{
    orderId:number;
    customer:Customer=new Customer();
    
   
}