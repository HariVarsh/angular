import { Component, OnInit } from '@angular/core';
import { Track } from '../Track';
import { TrackServiceService } from '../track-service.service';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  track:Track=new Track();
  data:any;
  constructor(private service:TrackServiceService) { }

  ngOnInit() {
  }

  onSubmit()
  {
    this.service.insertTrack(this.track).subscribe(data=>this.data=data)
  }


  add(a,b){
    return a+b;
  }

}
