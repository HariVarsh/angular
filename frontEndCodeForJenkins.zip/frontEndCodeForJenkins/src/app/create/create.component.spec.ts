import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateComponent } from './create.component';
import { BrowserModule } from '../../../node_modules/@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing'
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
describe('CreateComponent', () => {

  let component: CreateComponent;
  let fixture: ComponentFixture<CreateComponent>;


  //this method is executed b4 executing test cases
  //async synchronizes all the method in is file

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateComponent],
      imports: [BrowserModule, HttpClientTestingModule,HttpClientModule,FormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //every testcase vl be executed, fit means testcase for only that method vl be  executed.it won;t be executed if it is there
  it('should create', () => {
    expect(component).toBeTruthy();
  });


  fit('add test',()=>{
    expect(component.add(2,3)).toBe(5);
  })



});
