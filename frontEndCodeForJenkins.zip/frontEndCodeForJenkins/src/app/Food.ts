export class Food{
    foodId:number;
    foodName:string;
    price:any;
}