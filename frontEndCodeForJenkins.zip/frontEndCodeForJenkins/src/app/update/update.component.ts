import { Component, OnInit } from '@angular/core';
import { TrackServiceService } from '../track-service.service';
import { Track } from "../Track";
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  track: Track=new Track();
  data;
  constructor(private service: TrackServiceService) { }

  ngOnInit() {
  }
  onSubmit() {
    this.service.updateTracks(this.track.id,this.track.name).subscribe(data=>data=this.data);
  }

}
