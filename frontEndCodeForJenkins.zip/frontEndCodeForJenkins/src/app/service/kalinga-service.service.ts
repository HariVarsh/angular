import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { MyOrders } from '../MyOrders';
import { Customer } from '../Customer';
@Injectable({
  providedIn: 'root'
})
export class KalingaServiceService {
  // customer: Customer = new Customer();
  // myOrder: MyOrders = new MyOrders();
  constructor(private http: HttpClient) { }

  private _displayProducts = "http://localhost:8080/basket/displayProducts"
  private _signUp = "http://localhost:8080/basket/signUp"
  private _login = "http://localhost:8080/basket/login"
  private _placeOrder = "http://localhost:8080/basket/yourOrders"
  private _getRestaurant = "http://localhost:8080/basket/getRestaurant"

 

  displayProducts(id): Observable<any> {
    console.log(id)
    return this.http.get<any>(this._displayProducts+"/"+id);
  }

  signUp(customer): Observable<any> {

    return this.http.post<any>(this._signUp, customer);
  }

  login(name, pwd): Observable<object> {
    return this.http.get<any>(this._login + "/" + name + "/" + pwd);
  }

  placeOrder(myOrder): Observable<any> {
    console.log(myOrder)
    return this.http.post<any>(this._placeOrder,myOrder);
  }
  getRestaurant(): Observable<any> {
    return this.http.get<any>(this._getRestaurant);
  }
 



}
