import { Injectable, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';

@Injectable({
  providedIn: 'root'
})
export class EventEmitterService {
  invokeHeaderComponentFunction = new EventEmitter();
invokeLoginFunction=new EventEmitter();
  subsVar: Subscription;
  subsVarForLogin: Subscription;
  constructor() { }
  onDisplayComponentButtonClick() {
    this.invokeHeaderComponentFunction.emit();
  }

  onDeleteComponentButtonClick() {
    this.invokeHeaderComponentFunction.emit();
  }

  onLoginComponentButtonClick(){
     this.invokeLoginFunction.emit();
  } 

  /*
here, v need to invoke a function present in headercomponent from the display component.
to do this v use a emitter.
emitter has a function that emits the changes.
this function is invoked by the display component. now ven this emitter emits changes,
the header component vch is subscribed to it , invokes the function present in it.
  */
} 
