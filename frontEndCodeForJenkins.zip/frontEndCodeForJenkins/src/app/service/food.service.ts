import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
  foodId: any = [];
  foodName: any = [];
  customerEmail: string;
  restaurantId;
  json
  data
  cartFoodAndPrice = []
  price: any = []
  FoodIdArray = []
  constructor() { }
  getFoodId() {
    return this.foodId
  }
  setFoodId(pid) {
    this.foodId = (pid);
    console.log(this.foodId);
  }
  getFoodName() {
    return this.foodName;
  }
  setFoodName(name) {
    this.foodName.push(name);
    console.log(this.foodName);
  }
  getData() {
    return this.data;
  }
  setData(data) {
    this.data = data;
  }

  getCustomerEmail() {
    return this.customerEmail;
  }
  setCustomerEmail(email) {
    this.customerEmail = email;
    console.log(this.customerEmail);
  }

  getJson() {
    return this.json;
  }
  setJson(json) {
    this.json = (json);

  }
  getPrice() {
    return this.price;
  }
  setPrice(price) {
    this.price = price;
  }
  getResaurantId() {
    return this.restaurantId;
  }
  setRestaurantId(id) {
    this.restaurantId = id;
  }
  getFoodAndPrice() {
    return this.cartFoodAndPrice;
  }
  setFoodAndPrice(cartFoodAndPrice) {
    this.cartFoodAndPrice.push(cartFoodAndPrice);
  }
  setFoodIdArray(obj) {
    this.FoodIdArray.push(obj)
  }
  getFoodIdArray() {
    return this.FoodIdArray;
  }
}
