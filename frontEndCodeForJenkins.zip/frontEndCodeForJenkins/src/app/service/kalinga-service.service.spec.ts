import { TestBed } from '@angular/core/testing';

import { KalingaServiceService } from './kalinga-service.service';

describe('KalingaServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: KalingaServiceService = TestBed.get(KalingaServiceService);
    expect(service).toBeTruthy();
  });
});
