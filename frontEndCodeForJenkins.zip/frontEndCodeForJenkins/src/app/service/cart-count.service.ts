import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class CartCountService {
  count=0;
  constructor(){
  }
  ngOnInit(){
  }
  setCount(count) {
    this.count = count;
  }
  getCount() {
    return this.count;
  }
}
