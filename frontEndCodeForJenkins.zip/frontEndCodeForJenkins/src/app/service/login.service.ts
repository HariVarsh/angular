import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  isLoggedIn=false
  constructor() { }

  setLoginStatus(status) {
    this.isLoggedIn = status;
  }
  getLoginStatus(){
    return this.isLoggedIn;
  }
}
 