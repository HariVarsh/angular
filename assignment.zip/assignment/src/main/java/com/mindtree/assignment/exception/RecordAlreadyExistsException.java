package com.mindtree.assignment.exception;

public class RecordAlreadyExistsException extends MyApplicationException {

	public RecordAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecordAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public RecordAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecordAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RecordAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
