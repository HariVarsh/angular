const mongoose=require('mongoose')

const Schema=mongoose.Schema({
    contentType:
    {type:String},
    image:{}
})
module.exports=mongoose.model('mySchema',Schema);