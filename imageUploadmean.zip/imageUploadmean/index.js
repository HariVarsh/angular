var express = require('express');
var mongoose = require('mongoose')
var cors = require('cors');
var bodyParser = require('body-parser');
var path = require('path')
var multer = require('multer')
var fs = require("fs")
var ObjectId = require('mongodb').ObjectID;

const mySchema = require('./models/image')
//to start express
var app = express();
const port = 3000;
app.listen(port, () => {
    console.log("Connection established")
});

//middleware connection
app.use(cors());
app.use(bodyParser.json());

// //ROUTES WILL GO HERE
// app.get('/', function(req, res) {
//     res.json({ message: 'WELCOME' });   
// });

// ROUTES
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');

});


// SET STORAGE
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now())
    }
})

var upload = multer({ storage: storage })





//uploading single pic
app.post('/uploadfile', upload.single('myFile'), (req, res, next) => {
    const file = req.file
    if (!file) {
        const error = new Error('Please upload a file')
        error.httpStatusCode = 400
        return next(error)
    }
    res.send(file)

})


//uploading multiple pics
app.post('/uploadmultiple', upload.array('myFiles', 12), (req, res, next) => {
    const files = req.files
    if (!files) {
        const error = new Error('Please choose files')
        error.httpStatusCode = 400
        return next(error)
    }

    res.send(files)

})


//connect with mongo
mongoose.connect('mongodb://localhost:27017');
mongoose.connection.on("connected", () => {
    console.log("connected to mongo");
});
mongoose.connection.on("error", (err) => {
    console.log("failed to connect to mongo" + err);
});

//saving image to db
app.post('/uploadphoto', upload.single('myImage'), (req, res) => {
    var img = fs.readFileSync(req.file.path);
    var encode_image = img.toString('base64');
    // Define a JSONobject for the image attributes for saving to database
    let finalImg = new mySchema({
        contentType: req.file.mimetype,
        image: new Buffer(encode_image, 'base64')
    })
    finalImg.save((err, success) => {
        if (err) {
            res.json("Failed to add contact")
        }
        else {
            res.json("successfully added")
            // res.redirect('/')
        }
    })
})

app.get('/photos', (req, res) => {
    mySchema.find((err, result) => {
        const imgArray = result.map(element => element._id);
        console.log(imgArray);
        if (err) return console.log(err)
        res.send(imgArray)
    })
});



app.get('/photo/:id', (req, res) => {
    var filename = req.params.id;
    console.log(filename)
    mySchema.findOne({'_id': ObjectId(filename) }, (err, result) => {
        if (err) return console.log(err)
        else {
            res.contentType('image/jpeg');
           res.send(result.image.buffer)
            // res.send(result.image.buffer)
        }
    })
})