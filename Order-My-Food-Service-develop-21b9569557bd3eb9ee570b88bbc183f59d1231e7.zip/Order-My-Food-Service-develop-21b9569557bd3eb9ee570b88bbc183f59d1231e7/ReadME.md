Project Name: Order-My-Food

## enter all the service details your are using in your application