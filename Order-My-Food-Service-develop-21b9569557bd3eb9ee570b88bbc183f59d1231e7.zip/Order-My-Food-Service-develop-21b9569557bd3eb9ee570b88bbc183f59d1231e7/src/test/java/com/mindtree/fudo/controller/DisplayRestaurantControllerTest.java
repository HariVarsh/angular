package com.mindtree.fudo.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.fudo.dto.RestaurantDTO;
@RunWith(SpringJUnit4ClassRunner.class)
public class DisplayRestaurantControllerTest {

	private MockMvc mockMvc;
	@InjectMocks
	private DisplayRestaurantController displayRestaurantController;
	
	@Before
	public void setUp() throws Exception{
		mockMvc=MockMvcBuilders.standaloneSetup(displayRestaurantController).build();
	}
	
	@Test
	public void test() throws Exception {
		RestaurantDTO restaurantDTO= new RestaurantDTO();
	mockMvc.perform(MockMvcRequestBuilders.get("/fudo/restaurant/1"));
//	.andExpect(MockMvcResultMatchers.status().isOk())
//	.andExpect(MockMvcResultMatchers.content().contentType(restaurantDTO.js));
	}

}
