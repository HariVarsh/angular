package com.mindtree.fudo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FudoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FudoApplication.class, args);
	}

}
