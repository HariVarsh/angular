package com.mindtree.fudo.exceptions;

public class NotValidEmail extends MyApplicationException {

	public NotValidEmail() {
		super();
	}

	public NotValidEmail(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public NotValidEmail(String arg0) {
		super(arg0);
	}

	public NotValidEmail(Throwable arg0) {
		super(arg0);
	}

}
