package com.mindtree.fudo.service;

import java.util.Set;

import com.mindtree.fudo.entity.Restaurant;
import com.mindtree.fudo.exceptions.RecordNotFoundException;

public interface RestaurantService {

	Set<Restaurant> getRestaurant(int cityId) throws RecordNotFoundException;
}
