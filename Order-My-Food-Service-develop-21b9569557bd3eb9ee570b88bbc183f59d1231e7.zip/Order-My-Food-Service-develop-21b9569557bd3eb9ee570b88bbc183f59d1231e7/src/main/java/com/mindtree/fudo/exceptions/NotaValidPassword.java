package com.mindtree.fudo.exceptions;

public class NotaValidPassword extends MyApplicationException{

	public NotaValidPassword() {
		super();
	}

	public NotaValidPassword(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public NotaValidPassword(String arg0) {
		super(arg0);
	}

	public NotaValidPassword(Throwable arg0) {
		super(arg0);
	}

}
